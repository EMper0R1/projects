// ========================================= typing animation =========================================
var typed = new Typed(".typing", {
    strings: ["Web Designer", "Programmer", "Web Developer", "Graphic Designer,"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
});
